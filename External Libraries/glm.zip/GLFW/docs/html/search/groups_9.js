var searchData=
[
  ['window_20reference',['Window reference',['../group__window.html',1,'']]]
];
